
let cart = [];

function addToCart(id) {
  cart.push(id);
  alert('Продуктът е добавен в количката!');
}

document.getElementById('searchBar').addEventListener('input', function() {
  let val = this.value.toLowerCase();
  document.querySelectorAll('.product').forEach(p => {
    let visible = p.innerText.toLowerCase().includes(val);
    p.style.display = visible ? '' : 'none';
  });
});
